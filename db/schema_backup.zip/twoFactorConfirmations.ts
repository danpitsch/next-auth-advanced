import { sqliteTable, uniqueIndex, text } from 'drizzle-orm/sqlite-core'
import { id } from '../schema/schema-util'

import { users } from '../schema/users'

export const twoFactorConfirmations = sqliteTable(
	'twoFactorConfirmation',
	{
		id: id(),
		userId: text('userId')
			.notNull()
			.references(() => users.id, { onDelete: 'cascade', onUpdate: 'cascade' }),
	},
	(twoFactorConfirmation) => {
		return {
			userId_key: uniqueIndex('TwoFactorConfirmation_userId_key').on(
				twoFactorConfirmation.userId
			),
		}
	}
)

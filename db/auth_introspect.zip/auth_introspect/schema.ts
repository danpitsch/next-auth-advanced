import { sqliteTable, AnySQLiteColumn, uniqueIndex, foreignKey, text, integer, numeric } from "drizzle-orm/sqlite-core"
  import { sql } from "drizzle-orm"

export const Account = sqliteTable("Account", {
	id: text("id").primaryKey().notNull(),
	userId: text("userId").notNull().references(() => User.id, { onDelete: "cascade", onUpdate: "cascade" } ),
	type: text("type").notNull(),
	provider: text("provider").notNull(),
	providerAccountId: text("providerAccountId").notNull(),
	refresh_token: text("refresh_token"),
	access_token: text("access_token"),
	expires_at: integer("expires_at"),
	token_type: text("token_type"),
	scope: text("scope"),
	id_token: text("id_token"),
	session_state: text("session_state"),
},
(table) => {
	return {
		provider_providerAccountId_key: uniqueIndex("Account_provider_providerAccountId_key").on(table.provider, table.providerAccountId),
	}
});

export const VerificationToken = sqliteTable("VerificationToken", {
	id: text("id").primaryKey().notNull(),
	email: text("email").notNull(),
	token: text("token").notNull(),
	expires: numeric("expires").notNull(),
},
(table) => {
	return {
		email_token_key: uniqueIndex("VerificationToken_email_token_key").on(table.email, table.token),
		token_key: uniqueIndex("VerificationToken_token_key").on(table.token),
	}
});

export const PasswordResetToken = sqliteTable("PasswordResetToken", {
	id: text("id").primaryKey().notNull(),
	email: text("email").notNull(),
	token: text("token").notNull(),
	expires: numeric("expires").notNull(),
},
(table) => {
	return {
		email_token_key: uniqueIndex("PasswordResetToken_email_token_key").on(table.email, table.token),
		token_key: uniqueIndex("PasswordResetToken_token_key").on(table.token),
	}
});

export const TwoFactorToken = sqliteTable("TwoFactorToken", {
	id: text("id").primaryKey().notNull(),
	email: text("email").notNull(),
	token: text("token").notNull(),
	expires: numeric("expires").notNull(),
},
(table) => {
	return {
		email_token_key: uniqueIndex("TwoFactorToken_email_token_key").on(table.email, table.token),
		token_key: uniqueIndex("TwoFactorToken_token_key").on(table.token),
	}
});

export const TwoFactorConfirmation = sqliteTable("TwoFactorConfirmation", {
	id: text("id").primaryKey().notNull(),
	userId: text("userId").notNull().references(() => User.id, { onDelete: "cascade", onUpdate: "cascade" } ),
},
(table) => {
	return {
		userId_key: uniqueIndex("TwoFactorConfirmation_userId_key").on(table.userId),
	}
});

export const UserRole = sqliteTable("UserRole", {
	name: text("name").notNull(),
},
(table) => {
	return {
		name_key: uniqueIndex("UserRole_name_key").on(table.name),
	}
});

export const User = sqliteTable("User", {
	id: text("id").primaryKey().notNull(),
	name: text("name"),
	email: text("email"),
	emailVerified: numeric("emailVerified"),
	image: text("image"),
	password: text("password"),
	role: text("role").default("USER").notNull(),
	isTwoFactorEnabled: numeric("isTwoFactorEnabled").notNull(),
},
(table) => {
	return {
		email_key: uniqueIndex("User_email_key").on(table.email),
	}
});